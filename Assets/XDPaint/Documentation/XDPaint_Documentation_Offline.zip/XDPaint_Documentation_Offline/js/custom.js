(function() {
  function modifyLastNavItem() {
    const tabsNav = document.querySelector('.md-tabs__list');
    if (!tabsNav) return;

    const tabItems = tabsNav.querySelectorAll('.md-tabs__item');
    if (tabItems.length === 0) return;
    
    const lastTabLink = tabItems[tabItems.length - 1].querySelector('.md-tabs__link');
    if (!lastTabLink || lastTabLink.dataset.modified) return;

    // Only modify the link if it contains "Asset Store" in its text
    if (lastTabLink.textContent.includes('Asset Store')) {
      const handleClick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        window.open('https://assetstore.unity.com/packages/slug/212475', '_blank');
      };

      lastTabLink.addEventListener('click', handleClick);
      lastTabLink.dataset.modified = 'true';
    }

    const navItem = document.querySelector('.md-nav__item--active');
    if (navItem) {
      const navLink = navItem.querySelector('.md-nav__link');
      // Check if navLink and navLink.href are defined and valid
      if (navLink && navLink.href && navLink.href.includes('assetstore.unity.com') && !navLink.dataset.modified) {
        navLink.addEventListener('click', handleClick);
        navLink.dataset.modified = 'true';
      }
    }
  }

  function runModification() {
    modifyLastNavItem();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', runModification);
  } else {
    runModification();
  }

  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        runModification();
      }
    });
  });

  observer.observe(document.body, { childList: true, subtree: true });
})();